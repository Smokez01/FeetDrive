import pygame
from config import WIDTH, HEIGHT, FLOOR_Y

class Level1:
    def __init__(self, mountain_assets):
        # Levelgrenzen: z. B. von x=0 bis x=10000
        self.left_bound = 0
        self.right_bound = 10000

        # Himmel als Hintergrund
        self.sky = pygame.Surface((WIDTH, HEIGHT))
        self.sky.fill((135, 206, 235))  # Himmelblau

        # Bergbilder
        self.mountain_bg1 = mountain_assets["bg1"]
        self.mountain_bg2 = mountain_assets["bg2"]
        self.bg1_width = self.mountain_bg1.get_width()
        self.bg2_width = self.mountain_bg2.get_width()

        # Vordergrund-Bergbild
        self.mountain_fg = mountain_assets.get("foreground")
        self.fg_width = self.mountain_fg.get_width() if self.mountain_fg else 0

        # Y-Positionen
        self.y_bg = HEIGHT - self.mountain_bg1.get_height() - 100
        self.y_fg = HEIGHT - self.mountain_fg.get_height() - 50 if self.mountain_fg else 0

        # Hindernisse, z. B. ein roter Balken am Ende
        self.obstacles = []
        self.obstacles.append(pygame.Rect(10000, 0, 10, HEIGHT))
    
    def draw(self, screen, camera_x):
        factor_bg = 0.3
        factor_fg = 0.65

        # Himmel
        screen.blit(self.sky, (0, 0))
        
        # Berg-Hintergrund
        start_x = -camera_x * factor_bg
        screen.blit(self.mountain_bg1, (start_x, self.y_bg))
        
        x_start = start_x + self.bg1_width
        count = int((WIDTH - x_start) // self.bg2_width + 2)
        for i in range(count):
            x = x_start + i * self.bg2_width
            screen.blit(self.mountain_bg2, (x, self.y_bg))
        
        # Vordergrund
        if self.mountain_fg:
            fg_offset = camera_x * factor_fg
            for i in range(-1, int(WIDTH // self.fg_width) + 2):
                x_pos = i * self.fg_width - (fg_offset % self.fg_width)
                screen.blit(self.mountain_fg, (x_pos, self.y_fg))
        
        # Hindernisse
        for obs in self.obstacles:
            obs_draw = obs.copy()
            obs_draw.x -= camera_x
            pygame.draw.rect(screen, (200, 50, 50), obs_draw)

import sys, pygame, random
from config import WIDTH, HEIGHT, FPS, WHITE, FLOOR_Y
from assets import load_player_assets, load_environment_assets, load_fire_assets, load_mountain_assets
from player import Player
from fire_npc import FireNPC
from lvl1 import Level1

pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Schneemann Spiel")

def game_over_menu(screen):
    background = screen.copy()
    menu_size = (int(WIDTH * 0.2), int(HEIGHT * 0.65))
    menu_img = pygame.transform.scale(pygame.image.load("assets/images/menu.png"), menu_size)
    menu_rect = menu_img.get_rect(center=(WIDTH // 2, HEIGHT // 2))
    
    new_game_img = pygame.transform.scale(pygame.image.load("assets/images/new_game.png"), (200, 100))
    exit_img = pygame.transform.scale(pygame.image.load("assets/images/exit.png"), (200, 100))
    gap = 75
    new_game_rect = new_game_img.get_rect(center=(menu_rect.centerx, menu_rect.centery - gap))
    exit_rect = exit_img.get_rect(center=(menu_rect.centerx, menu_rect.centery + gap))
    
    clock = pygame.time.Clock()
    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if new_game_rect.collidepoint(pos):
                    return "new_game"
                if exit_rect.collidepoint(pos):
                    return "exit"
        screen.blit(background, (0, 0))
        screen.blit(menu_img, menu_rect)
        screen.blit(new_game_img, new_game_rect)
        screen.blit(exit_img, exit_rect)
        pygame.display.flip()

def main_game():
    # Assets laden
    pa = load_player_assets()
    ea = load_environment_assets()
    fa = load_fire_assets(pa["size"])
    mountain_assets = load_mountain_assets()
    level = Level1(mountain_assets)
    
    # Objekte erstellen
    player = Player(pa)
    fire = FireNPC(fa)
    
    clock = pygame.time.Clock()
    camera_x, game_over = 0, False
    # Variable, ob die Waffe bereits abgeholt wurde
    gun_picked = False
    # Waffe wird an einer festen x-Position (Levelkoordinate 300) platziert
    gun_level_x = 300
    # Berechne gun_y (über dem Boden)
    gun_img = ea.get("gun")
    gun_y = FLOOR_Y - gun_img.get_height() if gun_img else 0
    
    while True:
        clock.tick(FPS)
        screen.fill(WHITE)
        keys = pygame.key.get_pressed()
        old_x = player.x
        player.update(keys)
        
        # Spieler an Levelgrenzen begrenzen
        player.x = max(level.left_bound, min(player.x, level.right_bound - player.rect.width))
        player.rect.x = int(player.x)
        
        # Hinderniskollision prüfen
        for obs in level.obstacles:
            if player.rect.colliderect(obs):
                player.x = old_x
                player.rect.x = int(old_x)
                break
        
        camera_x = player.rect.x - WIDTH // 3 if player.rect.x > WIDTH // 3 else 0
        
        # Level zeichnen
        level.draw(screen, camera_x)
        
        # Boden zeichnen
        for x in range(-camera_x, WIDTH + camera_x, 50):
            img = ea["floor1"] if ((x + camera_x) // 50) % 2 == 0 else ea["floor2"]
            screen.blit(img, (x, FLOOR_Y))
        
        # Falls die Waffe noch nicht abgeholt wurde, zeichne sie
        if not gun_picked and gun_img:
            # gun_x relativ zur Kamera
            gun_x = gun_level_x - camera_x
            screen.blit(gun_img, (gun_x, gun_y))
            # Erstelle ein Rect für die Waffe
            gun_rect = pygame.Rect(gun_level_x, gun_y, gun_img.get_width(), gun_img.get_height())
            # Prüfe, ob Spieler mit der Waffe kollidiert
            if player.rect.colliderect(gun_rect):
                # Zeige Pickup-Prompt (E.png) über dem Spieler an
                pickup_img = ea.get("pickup")
                if pickup_img:
                    prompt_x = player.rect.centerx - pickup_img.get_width() // 2 - camera_x
                    prompt_y = player.rect.top - pickup_img.get_height() - 10
                    screen.blit(pickup_img, (prompt_x, prompt_y))
                # Wenn der Spieler E drückt, wird die Waffe aufgehoben
                if keys[pygame.K_e]:
                    gun_picked = True
        
        # FireNPC aktualisieren (Spielerposition als Tupel übergeben)
        fire.update((player.rect.x, player.rect.y))
        fire.draw(screen, camera_x)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
        
        # Kollision zwischen Spieler und FireNPC prüfen
        offset = (int(fire.x - player.rect.x), int(fire.y - player.rect.y))
        if player.get_mask().overlap(fire.get_mask(), offset):
            game_over = True
            break
        
        player.draw(screen, camera_x)
        pygame.display.flip()
    fire.fire_sound.stop()
    return game_over

def main():
    while True:
        if main_game():
            sel = game_over_menu(screen)
            if sel == "exit":
                break
        else:
            break
    pygame.quit(); sys.exit()

if __name__ == "__main__":
    main()

import pygame
import random
from config import WIDTH, HEIGHT, GENERAL_ANIMATION_SPEED, FIRE_SPEED
import math

class FireNPC:
    def __init__(self, assets):
        self.assets = assets
        self.size = assets["size"]
        self.x = random.randint(200, 1600)
        self.y = HEIGHT - self.size[1] - 50
        self.speed = FIRE_SPEED
        self.direction = 1  # 1 = rechts, -1 = links
        self.frame_index = 0
        self.state = "moving"
        self.state_timer = random.randint(120, 300)
        self.sound_playing = False  # Status, ob der Sound läuft

        # Initiales Bild (Bewegungsanimation bevorzugt)
        if self.assets.get("right_frames"):
            self.image = self.assets["right_frames"][0]
        else:
            self.image = self.assets.get("fallback")

        # Feuer-Sound aus den Assets
        self.fire_sound = self.assets.get("fire_sound")
        if self.fire_sound:
            self.fire_sound.set_volume(0)

    def update(self, player_pos):
        # Zustandswechsel
        self.state_timer -= 1
        if self.state_timer <= 0:
            self.frame_index = 0
            if self.state == "moving":
                self.state = "idle"
                self.state_timer = random.randint(60, 180)
            else:
                self.state = "moving"
                self.state_timer = random.randint(120, 300)

        if self.state == "moving":
            self.x += self.speed * self.direction
            if self.x <= 100 or self.x >= 1700:
                self.direction *= -1

            if self.direction > 0 and self.assets.get("right_frames"):
                self.frame_index = (self.frame_index + 1) % (len(self.assets["right_frames"]) * GENERAL_ANIMATION_SPEED)
                self.image = self.assets["right_frames"][self.frame_index // GENERAL_ANIMATION_SPEED]
            elif self.direction < 0 and self.assets.get("left_frames"):
                self.frame_index = (self.frame_index + 1) % (len(self.assets["left_frames"]) * GENERAL_ANIMATION_SPEED)
                self.image = self.assets["left_frames"][self.frame_index // GENERAL_ANIMATION_SPEED]
            else:
                self.image = self.assets.get("fallback")
        else:
            idle_frames = self.assets.get("idle_frames")
            if idle_frames and len(idle_frames) > 0:
                self.frame_index = (self.frame_index + 1) % (len(idle_frames) * GENERAL_ANIMATION_SPEED)
                self.image = idle_frames[self.frame_index // GENERAL_ANIMATION_SPEED]
            else:
                self.image = self.assets.get("static")
        
        self.update_sound(player_pos)

    def update_sound(self, player_pos):
        if not self.fire_sound:
            return

        dx = self.x - player_pos[0]
        dy = self.y - player_pos[1]
        distance = math.hypot(dx, dy)

        max_distance = 700
        if distance < max_distance:
            volume = max(0, 1 - (distance / max_distance))
        else:
            volume = 0

        self.fire_sound.set_volume(volume)
        if volume > 0 and not self.sound_playing:
            self.fire_sound.play(-1)
            self.sound_playing = True
        elif volume == 0 and self.sound_playing:
            self.fire_sound.stop()
            self.sound_playing = False

    def draw(self, screen, camera_x=0):
        screen.blit(self.image, (self.x - camera_x, self.y))

    def get_mask(self):
        return pygame.mask.from_surface(self.image)

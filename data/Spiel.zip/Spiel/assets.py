import os
import pygame
from PIL import Image, ImageSequence
from config import SCALE_FACTOR, WIDTH, HEIGHT

def load_gif_frames(gif_path, size):
    if os.path.exists(gif_path):
        gif = Image.open(gif_path)
        frames = []
        for frame in ImageSequence.Iterator(gif):
            image = pygame.image.fromstring(
                frame.convert("RGBA").tobytes(),
                frame.size,
                "RGBA"
            )
            image = pygame.transform.scale(image, size)
            frames.append(image)
        return frames
    return []

def load_player_assets():
    # Statische Bilder laden
    schneemann_right_static = pygame.image.load("assets/images/schneemann_right.png")
    schneemann_left_static = pygame.image.load("assets/images/schneemann_left.png")
    
    # Größe ermitteln und skalieren
    orig_width, orig_height = schneemann_right_static.get_size()
    new_size = (int(orig_width * SCALE_FACTOR), int(orig_height * SCALE_FACTOR))
    schneemann_right_static = pygame.transform.scale(schneemann_right_static, new_size)
    schneemann_left_static = pygame.transform.scale(schneemann_left_static, new_size)
    
    # Animationen laden
    schneemann_right_frames = load_gif_frames("assets/gifs/schneemann_right.gif", new_size)
    schneemann_left_frames = load_gif_frames("assets/gifs/schneemann_left.gif", new_size)
    jump_right_frames = load_gif_frames("assets/gifs/jump_right.gif", new_size)
    jump_left_frames = load_gif_frames("assets/gifs/jump_left.gif", new_size)
    jump_frames = load_gif_frames("assets/gifs/jump.gif", new_size)
    
    # Ducking – links
    crouch_left_frames = load_gif_frames("assets/gifs/crouch_left.gif", new_size)
    uncrouch_left_frames = load_gif_frames("assets/gifs/uncrouch_left.gif", new_size)
    crouched_left = pygame.image.load("assets/images/crouched_left.png")
    crouched_left = pygame.transform.scale(crouched_left, new_size)
    
    # Ducking – rechts
    crouch_right_frames = load_gif_frames("assets/gifs/crouch_right.gif", new_size)
    uncrouch_right_frames = load_gif_frames("assets/gifs/uncrouch_right.gif", new_size)
    crouched_right = pygame.image.load("assets/images/crouched_right.png")
    crouched_right = pygame.transform.scale(crouched_right, new_size)
    
    assets = {
        "static_right": schneemann_right_static,
        "static_left": schneemann_left_static,
        "right_frames": schneemann_right_frames,
        "left_frames": schneemann_left_frames,
        "jump_right_frames": jump_right_frames,
        "jump_left_frames": jump_left_frames,
        "jump_frames": jump_frames,
        "crouch_left_frames": crouch_left_frames,
        "uncrouch_left_frames": uncrouch_left_frames,
        "crouched_left": crouched_left,
        "crouch_right_frames": crouch_right_frames,
        "uncrouch_right_frames": uncrouch_right_frames,
        "crouched_right": crouched_right,
        "size": new_size
    }
    return assets

def load_environment_assets():
    floor1 = pygame.image.load("assets/images/floor1.png")
    floor2 = pygame.image.load("assets/images/floor2.png")
    floor1 = pygame.transform.scale(floor1, (50, 50))
    floor2 = pygame.transform.scale(floor2, (50, 50))
    portal = pygame.image.load("assets/images/portal.png")
    portal = pygame.transform.scale(portal, (50, 100))
    # Waffe laden und auf 75x75 skalieren
    gun = pygame.image.load("assets/images/gun.png")
    gun = pygame.transform.scale(gun, (75, 75))
    # Pickup-Prompt (E.png) laden und skalieren (z. B. 50x50)
    pickup = pygame.image.load("assets/images/E.png")
    pickup = pygame.transform.scale(pickup, (100, 100))
    
    env_assets = {
        "floor1": floor1,
        "floor2": floor2,
        "portal": portal,
        "gun": gun,
        "pickup": pickup
    }
    return env_assets

def load_fire_assets(player_size):
    # Größe des Feuer-NPCs (halbe Spielergröße)
    fire_size = (player_size[0] // 2, player_size[1] // 2)
    fire_right_frames = load_gif_frames("assets/gifs/fire_right.gif", fire_size)
    fire_left_frames = load_gif_frames("assets/gifs/fire_left.gif", fire_size)
    if not fire_left_frames and fire_right_frames:
        fire_left_frames = [pygame.transform.flip(frame, True, False) for frame in fire_right_frames]
    idle_frames = load_gif_frames("assets/gifs/fire.gif", fire_size)
    fallback_fire = pygame.Surface(fire_size)
    fallback_fire.fill((255, 0, 0))
    # Feuer-Sound laden
    fire_sound = pygame.mixer.Sound("assets/sounds/fire.mp3")
    assets = {
        "right_frames": fire_right_frames,
        "left_frames": fire_left_frames,
        "idle_frames": idle_frames,
        "fallback": fallback_fire,
        "fire_sound": fire_sound,
        "size": fire_size
    }
    return assets

def load_mountain_assets():
    mountain_bg1 = pygame.image.load("assets/images/mountain_bg1.png").convert_alpha()
    mountain_bg2 = pygame.image.load("assets/images/mountain_bg2.png").convert_alpha()
    mountain_fg = pygame.image.load("assets/images/mountain_fg.png").convert_alpha()
    assets = {
        "bg1": mountain_bg1,
        "bg2": mountain_bg2,
        "foreground": mountain_fg
    }
    return assets

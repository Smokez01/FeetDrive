import pygame

# Fenster- und Spiel-Einstellungen
WIDTH, HEIGHT = 1920, 1080
FPS = 60

# Farben
WHITE = (180, 180, 255)
RED = (255, 0, 0)

# Skalierung und Animation
SCALE_FACTOR = 5.5
GENERAL_ANIMATION_SPEED = 5
CROUCH_ANIMATION_SPEED = 1
UNCROUCH_ANIMATION_SPEED = 1

# Spieler- und Sprung-Einstellungen
JUMP_HEIGHT = 120
FLOOR_Y = HEIGHT - 50

# Portal-Position (falls benötigt)
PORTAL_X = 1600
PORTAL_Y = HEIGHT - 150

# Fire NPC Einstellungen
FIRE_SPEED = 4
